/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_LoginDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTextBrowser *textBrowser;
    QLabel *label;
    QLineEdit *userlineEdit;
    QLabel *label_2;
    QLineEdit *passwordlineEdit;
    QPushButton *loginpushButton;
    QPushButton *exitpushButton;

    void setupUi(QDialog *LoginDialog)
    {
        if (LoginDialog->objectName().isEmpty())
            LoginDialog->setObjectName(QString::fromUtf8("LoginDialog"));
        LoginDialog->resize(1082, 313);
        verticalLayout = new QVBoxLayout(LoginDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textBrowser = new QTextBrowser(LoginDialog);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setEnabled(false);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(15);
        textBrowser->setFont(font);

        verticalLayout->addWidget(textBrowser);

        label = new QLabel(LoginDialog);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font1;
        font1.setPointSize(20);
        label->setFont(font1);

        verticalLayout->addWidget(label);

        userlineEdit = new QLineEdit(LoginDialog);
        userlineEdit->setObjectName(QString::fromUtf8("userlineEdit"));
        userlineEdit->setFont(font1);

        verticalLayout->addWidget(userlineEdit);

        label_2 = new QLabel(LoginDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        verticalLayout->addWidget(label_2);

        passwordlineEdit = new QLineEdit(LoginDialog);
        passwordlineEdit->setObjectName(QString::fromUtf8("passwordlineEdit"));
        passwordlineEdit->setFont(font1);
        passwordlineEdit->setContextMenuPolicy(Qt::DefaultContextMenu);
        passwordlineEdit->setEchoMode(QLineEdit::Password);

        verticalLayout->addWidget(passwordlineEdit);

        loginpushButton = new QPushButton(LoginDialog);
        loginpushButton->setObjectName(QString::fromUtf8("loginpushButton"));
        QFont font2;
        font2.setPointSize(19);
        loginpushButton->setFont(font2);

        verticalLayout->addWidget(loginpushButton);

        exitpushButton = new QPushButton(LoginDialog);
        exitpushButton->setObjectName(QString::fromUtf8("exitpushButton"));
        exitpushButton->setFont(font2);

        verticalLayout->addWidget(exitpushButton);


        retranslateUi(LoginDialog);
        QObject::connect(exitpushButton, SIGNAL(clicked()), LoginDialog, SLOT(close()));

        QMetaObject::connectSlotsByName(LoginDialog);
    } // setupUi

    void retranslateUi(QDialog *LoginDialog)
    {
        LoginDialog->setWindowTitle(QApplication::translate("LoginDialog", "Dialog", nullptr));
        textBrowser->setHtml(QApplication::translate("LoginDialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Arial'; font-size:15pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" dir='rtl' style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:20pt;\">Camping Equipment Loaning System</span></p></body></html>", nullptr));
        label->setText(QApplication::translate("LoginDialog", "user:", nullptr));
        label_2->setText(QApplication::translate("LoginDialog", "password:", nullptr));
        loginpushButton->setText(QApplication::translate("LoginDialog", "login", nullptr));
        exitpushButton->setText(QApplication::translate("LoginDialog", "exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginDialog: public Ui_LoginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
