#include "userc.h"

    User::User(QString id) {
        UID = id;
        QString line = searchData(Ufile, UID);
        Name = searchPart(line, 2);
        Section = searchPart(line, 3);
        DateOfBirth = searchPart(line, 4);
        Address = searchPart(line, 5);
		if(judgeRank())
			Rank = searchPart(line, 6);
    }

    QString User::getName() {
        return Name;
    }

    QString User::getSection() {
        return Section;
    };

    QString User::getDateOfBirth() {
        return DateOfBirth;
    }

    QString User::getAddress() {
        return Address;
    }

    QString User::getRank(){
        return Rank;
    }

    void User::setName(QString name) {
        Name = name;
    }

    void User::setSection(QString section) {
        Section = section;
    };

    void User::setDateOfBirth(QString dateofbirth) {
        DateOfBirth = dateofbirth;
    }

    void User::setAddress(QString address) {
        Address = address;
    }

    void User::setRank(QString rank) {
        Rank = rank;
    }
	//judge if it have rank or not
    bool User::judgeRank() {
        if (Rank.compare("wrong")==0)
            return false;
        else
            return true;
    }

	void User::saveadd() {
		int	lineVENend = searchlineN(Ufile, "ROV");
		int	lineROVend = searchlineN(Ufile, "SCT");
		int lineSCTend = searchlineN(Ufile, "SCM");
		int lineSCMend = countLines(Ufile)+1;
		QString changeL;
		QString Uline = searchData(Ufile, UID);
		//ven
		if (UID.compare("VEN")==0) {
			if (lineVENend < 10)
				UID = "VEN00" + QString::number(lineVENend);
			else if (lineVENend >= 10 && lineVENend < 100)
				UID = "VEN0" + QString::number(lineVENend);
			else
				UID = "VEN" + QString::number(lineVENend);
			changeL=UID + "|" + Name + "|" + Section + "|" + DateOfBirth + "|" + Address;
			addText(Ufile, lineVENend, changeL);
		}
		//rov
		else if (UID.compare("ROV") == 0) {
			if ((lineROVend-lineVENend+1) < 10)
				UID = "ROV00" + QString::number(lineROVend - lineVENend+1);
			else if ((lineROVend - lineVENend+1) >= 10 && (lineROVend - lineVENend+1) < 100)
				UID = "ROV0" + QString::number(lineROVend - lineVENend+1);
			else
				UID = "ROV" + QString::number(lineROVend - lineVENend+1);
			changeL = UID + "|" + Name + "|" + Section + "|" + DateOfBirth + "|" + Address;
			addText(Ufile, lineROVend, changeL);
		}
		//sct
		else if (UID.compare("SCT") == 0) {
			if ((lineSCTend - lineROVend+1) < 10)
				UID = "SCT00" + QString::number(lineSCTend - lineROVend+1);
			else if ((lineSCTend - lineROVend+1) >= 10 && (lineSCTend - lineROVend+1) < 100)
				UID = "SCT0" + QString::number(lineSCTend - lineROVend+1);
			else
				UID = "SCT" + QString::number(lineSCTend - lineROVend+1);
			changeL = UID + "|" + Name + "|" + Section + "|" + DateOfBirth + "|" + Address+"|"+Rank;
			addText(Ufile, lineSCTend, changeL);
		}
		//scm
		else {
			if ((lineSCMend - lineSCTend+1) < 10)
				UID = "SCM00" + QString::number(lineSCTend - lineROVend+1);
			else if ((lineSCMend - lineSCTend+1) >= 10 && (lineSCMend - lineSCTend+1) < 100)
				UID = "SCM0" + QString::number(lineSCMend - lineSCTend+1);
			else
				UID = "SCM" + QString::number(lineSCMend - lineSCTend+1);
			changeL = UID + "|" + Name + "|" + Section + "|" + DateOfBirth + "|" + Address + "|" + Rank;
			addText(Ufile, lineSCMend, changeL);
		}
	};

	void User::savechange() {
		QString changeL = UID + "|" + Name + "|" + Section + "|" + DateOfBirth + "|" + Address;
		if (judgeRank())
			changeL = changeL + "|" + Rank;
		changeLine(Ufile, searchlineN(Ufile, UID), changeL);
	}

	void User::savedel() {
		QString change;
		int numberOfLine = searchlineN(Ufile, UID);
		//VEN
		if (UID.startsWith("VEN")) {
			change = UID + "||Venture Scout||";
		}
		//ROV
		else if (UID.startsWith("ROV")) {
			change = UID + "||Rover Scout||";
		}
		//SCT
		else if (UID.startsWith("SCT")) {
			change = UID + "||Scout|||";
		}
		//SCM
		else{
			change = UID + "||Rover Scout|||";
			}
		changeLine(Ufile, searchlineN(Ufile, UID), change);
	}

	//find all the items that have been borrowed
	QString User::GoodsOfBorrow() {
			QString str = "";
			QFile nfile(Efile);
			nfile.open(QIODevice::ReadOnly | QIODevice::Text);
			QTextStream in(&nfile);
			while (!nfile.atEnd()) {
				QString line = nfile.readLine();
				if (line.startsWith("T")){
					if (searchPart(line, 14).startsWith(UID)) {
						str += line;
					}
				}
				else if (line.startsWith("S")) {
					if (searchPart(line, 11).startsWith(UID)) {
						str += line;
					}
				}
				else {
					if (searchPart(line, 12).startsWith(UID)) {
						str += line;
					}
				}
			}
			nfile.close();
			return str;
	}

	////find how many items that can borrow now
	int User::NumberOfBorrow() {
		int count=0;
		QFile nfile(Efile);
		nfile.open(QIODevice::ReadOnly | QIODevice::Text);
		QTextStream in(&nfile);
		while (!nfile.atEnd()) {
			QString line = nfile.readLine();
			if (line.startsWith("T")) {
				if (searchPart(line, 14).startsWith(UID)) {
					count++;
				}
			}
			else if (line.startsWith("S")) {
				if (searchPart(line, 11).startsWith(UID)) {
					count++;
				}
			}
			else {
				if (searchPart(line, 12).startsWith(UID)) {
					count++;
				}
			}
		}
		nfile.close();
		return count;
	}

	//find the max items that can borrow
	int User::MaxBorrow() {
		if (UID.startsWith("VEN")) {
			return 3;
		}
		else if (UID.startsWith("ROV")) {
			return 5;
		}
		else if (UID.startsWith("SCT")) {
			if (Rank.startsWith("Member")) {
				return 1;
			}
			else
				return 3;
		}
		else
			return 5;
	}

	//loan control
	bool User::judgeBorrow() {
		if (NumberOfBorrow() == 0) {
			return true;
		}
		if (NumberOfBorrow()>=MaxBorrow()){
			return false;
		}
		else {
			QStringList list = GoodsOfBorrow().split("\n");
			for (int i = 0; i < list.length(); i++) {
				int BorrowT;
				QString line = list.at(i);
				if (line.startsWith("T")) {
					BorrowT = Timeinterval(searchPart(line, 13));
				}
				if (line.startsWith("S")) {
					BorrowT = Timeinterval(searchPart(line, 10));
				}
				if (line.startsWith("L")) {
					BorrowT = Timeinterval(searchPart(line, 11));
				}
				if (BorrowT > 14){
					return false;
				}
			}
			return true;
		}
	}