/********************************************************************************
** Form generated from reading UI file 'e_acdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_E_ACDIALOG_H
#define UI_E_ACDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_E_ACDialog
{
public:
    QVBoxLayout *verticalLayout;
    QPushButton *addButton;
    QPushButton *changeButton;
    QPushButton *deleteButton;
    QHBoxLayout *horizontalLayout;
    QLabel *IDlabel;
    QComboBox *IDcomboBox;
    QLineEdit *IDtextEdit;
    QLabel *namelabel;
    QLineEdit *nametextEdit;
    QLabel *brandlabel;
    QLineEdit *brandtextEdit;
    QLabel *DOBlabel;
    QLineEdit *DOBtextEdit;
    QLabel *condationlabel;
    QComboBox *conditioncomboBox;
    QLabel *ppllabel;
    QLineEdit *ppltextEdit;
    QLabel *doorlabel;
    QLineEdit *doortextEdit;
    QLabel *usagelabel;
    QComboBox *usagecomboBox;
    QLabel *typelabel;
    QLineEdit *typetextEdit;
    QLabel *Ftypelabel;
    QLineEdit *FtypetextEdit;
    QLabel *DLlabel;
    QComboBox *DLcomboBox;
    QLabel *colourlabel;
    QLineEdit *colourtextEdit;
    QPushButton *addOKButton;
    QPushButton *changeOKButton;
    QPushButton *deleteOKButton;
    QPushButton *addsaveButton;
    QPushButton *changesaveButton;
    QPushButton *backButton;

    void setupUi(QDialog *E_ACDialog)
    {
        if (E_ACDialog->objectName().isEmpty())
            E_ACDialog->setObjectName(QString::fromUtf8("E_ACDialog"));
        E_ACDialog->resize(602, 994);
        verticalLayout = new QVBoxLayout(E_ACDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        addButton = new QPushButton(E_ACDialog);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        verticalLayout->addWidget(addButton);

        changeButton = new QPushButton(E_ACDialog);
        changeButton->setObjectName(QString::fromUtf8("changeButton"));

        verticalLayout->addWidget(changeButton);

        deleteButton = new QPushButton(E_ACDialog);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        verticalLayout->addWidget(deleteButton);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        IDlabel = new QLabel(E_ACDialog);
        IDlabel->setObjectName(QString::fromUtf8("IDlabel"));
        QFont font;
        font.setPointSize(20);
        IDlabel->setFont(font);

        horizontalLayout->addWidget(IDlabel);

        IDcomboBox = new QComboBox(E_ACDialog);
        IDcomboBox->addItem(QString());
        IDcomboBox->addItem(QString());
        IDcomboBox->addItem(QString());
        IDcomboBox->setObjectName(QString::fromUtf8("IDcomboBox"));

        horizontalLayout->addWidget(IDcomboBox);

        IDtextEdit = new QLineEdit(E_ACDialog);
        IDtextEdit->setObjectName(QString::fromUtf8("IDtextEdit"));

        horizontalLayout->addWidget(IDtextEdit);


        verticalLayout->addLayout(horizontalLayout);

        namelabel = new QLabel(E_ACDialog);
        namelabel->setObjectName(QString::fromUtf8("namelabel"));
        namelabel->setFont(font);

        verticalLayout->addWidget(namelabel);

        nametextEdit = new QLineEdit(E_ACDialog);
        nametextEdit->setObjectName(QString::fromUtf8("nametextEdit"));

        verticalLayout->addWidget(nametextEdit);

        brandlabel = new QLabel(E_ACDialog);
        brandlabel->setObjectName(QString::fromUtf8("brandlabel"));
        brandlabel->setFont(font);

        verticalLayout->addWidget(brandlabel);

        brandtextEdit = new QLineEdit(E_ACDialog);
        brandtextEdit->setObjectName(QString::fromUtf8("brandtextEdit"));

        verticalLayout->addWidget(brandtextEdit);

        DOBlabel = new QLabel(E_ACDialog);
        DOBlabel->setObjectName(QString::fromUtf8("DOBlabel"));
        DOBlabel->setFont(font);

        verticalLayout->addWidget(DOBlabel);

        DOBtextEdit = new QLineEdit(E_ACDialog);
        DOBtextEdit->setObjectName(QString::fromUtf8("DOBtextEdit"));

        verticalLayout->addWidget(DOBtextEdit);

        condationlabel = new QLabel(E_ACDialog);
        condationlabel->setObjectName(QString::fromUtf8("condationlabel"));
        condationlabel->setFont(font);

        verticalLayout->addWidget(condationlabel);

        conditioncomboBox = new QComboBox(E_ACDialog);
        conditioncomboBox->addItem(QString());
        conditioncomboBox->addItem(QString());
        conditioncomboBox->addItem(QString());
        conditioncomboBox->addItem(QString());
        conditioncomboBox->setObjectName(QString::fromUtf8("conditioncomboBox"));

        verticalLayout->addWidget(conditioncomboBox);

        ppllabel = new QLabel(E_ACDialog);
        ppllabel->setObjectName(QString::fromUtf8("ppllabel"));
        ppllabel->setFont(font);

        verticalLayout->addWidget(ppllabel);

        ppltextEdit = new QLineEdit(E_ACDialog);
        ppltextEdit->setObjectName(QString::fromUtf8("ppltextEdit"));

        verticalLayout->addWidget(ppltextEdit);

        doorlabel = new QLabel(E_ACDialog);
        doorlabel->setObjectName(QString::fromUtf8("doorlabel"));
        doorlabel->setFont(font);

        verticalLayout->addWidget(doorlabel);

        doortextEdit = new QLineEdit(E_ACDialog);
        doortextEdit->setObjectName(QString::fromUtf8("doortextEdit"));

        verticalLayout->addWidget(doortextEdit);

        usagelabel = new QLabel(E_ACDialog);
        usagelabel->setObjectName(QString::fromUtf8("usagelabel"));
        usagelabel->setFont(font);

        verticalLayout->addWidget(usagelabel);

        usagecomboBox = new QComboBox(E_ACDialog);
        usagecomboBox->addItem(QString());
        usagecomboBox->addItem(QString());
        usagecomboBox->setObjectName(QString::fromUtf8("usagecomboBox"));

        verticalLayout->addWidget(usagecomboBox);

        typelabel = new QLabel(E_ACDialog);
        typelabel->setObjectName(QString::fromUtf8("typelabel"));
        typelabel->setFont(font);

        verticalLayout->addWidget(typelabel);

        typetextEdit = new QLineEdit(E_ACDialog);
        typetextEdit->setObjectName(QString::fromUtf8("typetextEdit"));

        verticalLayout->addWidget(typetextEdit);

        Ftypelabel = new QLabel(E_ACDialog);
        Ftypelabel->setObjectName(QString::fromUtf8("Ftypelabel"));
        Ftypelabel->setFont(font);

        verticalLayout->addWidget(Ftypelabel);

        FtypetextEdit = new QLineEdit(E_ACDialog);
        FtypetextEdit->setObjectName(QString::fromUtf8("FtypetextEdit"));

        verticalLayout->addWidget(FtypetextEdit);

        DLlabel = new QLabel(E_ACDialog);
        DLlabel->setObjectName(QString::fromUtf8("DLlabel"));
        DLlabel->setFont(font);

        verticalLayout->addWidget(DLlabel);

        DLcomboBox = new QComboBox(E_ACDialog);
        DLcomboBox->addItem(QString());
        DLcomboBox->addItem(QString());
        DLcomboBox->setObjectName(QString::fromUtf8("DLcomboBox"));

        verticalLayout->addWidget(DLcomboBox);

        colourlabel = new QLabel(E_ACDialog);
        colourlabel->setObjectName(QString::fromUtf8("colourlabel"));
        colourlabel->setFont(font);

        verticalLayout->addWidget(colourlabel);

        colourtextEdit = new QLineEdit(E_ACDialog);
        colourtextEdit->setObjectName(QString::fromUtf8("colourtextEdit"));

        verticalLayout->addWidget(colourtextEdit);

        addOKButton = new QPushButton(E_ACDialog);
        addOKButton->setObjectName(QString::fromUtf8("addOKButton"));

        verticalLayout->addWidget(addOKButton);

        changeOKButton = new QPushButton(E_ACDialog);
        changeOKButton->setObjectName(QString::fromUtf8("changeOKButton"));

        verticalLayout->addWidget(changeOKButton);

        deleteOKButton = new QPushButton(E_ACDialog);
        deleteOKButton->setObjectName(QString::fromUtf8("deleteOKButton"));

        verticalLayout->addWidget(deleteOKButton);

        addsaveButton = new QPushButton(E_ACDialog);
        addsaveButton->setObjectName(QString::fromUtf8("addsaveButton"));

        verticalLayout->addWidget(addsaveButton);

        changesaveButton = new QPushButton(E_ACDialog);
        changesaveButton->setObjectName(QString::fromUtf8("changesaveButton"));

        verticalLayout->addWidget(changesaveButton);

        backButton = new QPushButton(E_ACDialog);
        backButton->setObjectName(QString::fromUtf8("backButton"));

        verticalLayout->addWidget(backButton);


        retranslateUi(E_ACDialog);
        QObject::connect(backButton, SIGNAL(clicked()), E_ACDialog, SLOT(close()));
        QObject::connect(changesaveButton, SIGNAL(clicked()), E_ACDialog, SLOT(accept()));
        QObject::connect(addsaveButton, SIGNAL(clicked()), E_ACDialog, SLOT(accept()));
        QObject::connect(deleteOKButton, SIGNAL(clicked()), E_ACDialog, SLOT(accept()));

        QMetaObject::connectSlotsByName(E_ACDialog);
    } // setupUi

    void retranslateUi(QDialog *E_ACDialog)
    {
        E_ACDialog->setWindowTitle(QApplication::translate("E_ACDialog", "Dialog", nullptr));
        addButton->setText(QApplication::translate("E_ACDialog", "add(A)", nullptr));
#ifndef QT_NO_SHORTCUT
        addButton->setShortcut(QApplication::translate("E_ACDialog", "A", nullptr));
#endif // QT_NO_SHORTCUT
        changeButton->setText(QApplication::translate("E_ACDialog", "change(C)", nullptr));
#ifndef QT_NO_SHORTCUT
        changeButton->setShortcut(QApplication::translate("E_ACDialog", "C", nullptr));
#endif // QT_NO_SHORTCUT
        deleteButton->setText(QApplication::translate("E_ACDialog", "delete(D)", nullptr));
#ifndef QT_NO_SHORTCUT
        deleteButton->setShortcut(QApplication::translate("E_ACDialog", "D", nullptr));
#endif // QT_NO_SHORTCUT
        IDlabel->setText(QApplication::translate("E_ACDialog", "ID\357\274\232", nullptr));
        IDcomboBox->setItemText(0, QApplication::translate("E_ACDialog", "tent", nullptr));
        IDcomboBox->setItemText(1, QApplication::translate("E_ACDialog", "stove", nullptr));
        IDcomboBox->setItemText(2, QApplication::translate("E_ACDialog", "lantern", nullptr));

        namelabel->setText(QApplication::translate("E_ACDialog", "name:", nullptr));
        brandlabel->setText(QApplication::translate("E_ACDialog", "brand:", nullptr));
        DOBlabel->setText(QApplication::translate("E_ACDialog", "date of purchase:", nullptr));
        condationlabel->setText(QApplication::translate("E_ACDialog", "condition:", nullptr));
        conditioncomboBox->setItemText(0, QApplication::translate("E_ACDialog", "good", nullptr));
        conditioncomboBox->setItemText(1, QApplication::translate("E_ACDialog", "being repaired", nullptr));
        conditioncomboBox->setItemText(2, QApplication::translate("E_ACDialog", "damage", nullptr));
        conditioncomboBox->setItemText(3, QApplication::translate("E_ACDialog", "disposed", nullptr));

        ppllabel->setText(QApplication::translate("E_ACDialog", "number of ppl\357\274\232", nullptr));
        doorlabel->setText(QApplication::translate("E_ACDialog", "number of doors\357\274\232", nullptr));
        usagelabel->setText(QApplication::translate("E_ACDialog", "usage", nullptr));
        usagecomboBox->setItemText(0, QApplication::translate("E_ACDialog", "hiking", nullptr));
        usagecomboBox->setItemText(1, QApplication::translate("E_ACDialog", "camping", nullptr));

        typelabel->setText(QApplication::translate("E_ACDialog", "type:", nullptr));
        Ftypelabel->setText(QApplication::translate("E_ACDialog", "fuel type:", nullptr));
        DLlabel->setText(QApplication::translate("E_ACDialog", "double-layer:", nullptr));
        DLcomboBox->setItemText(0, QApplication::translate("E_ACDialog", "true", nullptr));
        DLcomboBox->setItemText(1, QApplication::translate("E_ACDialog", "false", nullptr));

        colourlabel->setText(QApplication::translate("E_ACDialog", "colour:", nullptr));
        addOKButton->setText(QApplication::translate("E_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        addOKButton->setShortcut(QApplication::translate("E_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        changeOKButton->setText(QApplication::translate("E_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        changeOKButton->setShortcut(QApplication::translate("E_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        deleteOKButton->setText(QApplication::translate("E_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        deleteOKButton->setShortcut(QApplication::translate("E_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        addsaveButton->setText(QApplication::translate("E_ACDialog", "save", nullptr));
#ifndef QT_NO_SHORTCUT
        addsaveButton->setShortcut(QApplication::translate("E_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        changesaveButton->setText(QApplication::translate("E_ACDialog", "save", nullptr));
#ifndef QT_NO_SHORTCUT
        changesaveButton->setShortcut(QApplication::translate("E_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        backButton->setText(QApplication::translate("E_ACDialog", "back(B)", nullptr));
#ifndef QT_NO_SHORTCUT
        backButton->setShortcut(QApplication::translate("E_ACDialog", "B", nullptr));
#endif // QT_NO_SHORTCUT
    } // retranslateUi

};

namespace Ui {
    class E_ACDialog: public Ui_E_ACDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_E_ACDIALOG_H
