#ifndef USERC_H
#define USERC_H

#include "basicf.h"

class User {
private:
    QString UID;
    QString Name;
    QString Section;
    QString DateOfBirth;
    QString Address;
    QString Rank;
public:
    User(QString id);

    QString getName();

    QString getSection();

    QString getDateOfBirth();

    QString getAddress();

    QString getRank();

    void setName(QString name);

    void setSection(QString section);

    void setDateOfBirth(QString dateofbirth);

    void setAddress(QString address);

    void setRank(QString rank);

    bool judgeRank();

	void savechange();

	void saveadd();

	void savedel();	

	QString GoodsOfBorrow();

	int MaxBorrow();

	int NumberOfBorrow();

	bool judgeBorrow();
};

#endif // USERC_H
