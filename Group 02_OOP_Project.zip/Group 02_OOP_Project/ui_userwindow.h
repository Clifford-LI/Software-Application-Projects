/********************************************************************************
** Form generated from reading UI file 'userwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERWINDOW_H
#define UI_USERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserWindow
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *borrowButton;
    QPushButton *returnButton;
    QPushButton *exitButton;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QTextBrowser *BtextBrowser;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QTextBrowser *textBrowser;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *UserWindow)
    {
        if (UserWindow->objectName().isEmpty())
            UserWindow->setObjectName(QString::fromUtf8("UserWindow"));
        UserWindow->resize(2208, 1044);
        centralwidget = new QWidget(UserWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 793, 2181, 201));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        borrowButton = new QPushButton(verticalLayoutWidget);
        borrowButton->setObjectName(QString::fromUtf8("borrowButton"));
        QFont font;
        font.setPointSize(20);
        borrowButton->setFont(font);

        verticalLayout->addWidget(borrowButton);

        returnButton = new QPushButton(verticalLayoutWidget);
        returnButton->setObjectName(QString::fromUtf8("returnButton"));
        returnButton->setFont(font);

        verticalLayout->addWidget(returnButton);

        exitButton = new QPushButton(verticalLayoutWidget);
        exitButton->setObjectName(QString::fromUtf8("exitButton"));
        exitButton->setFont(font);

        verticalLayout->addWidget(exitButton);

        verticalLayoutWidget_3 = new QWidget(centralwidget);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(10, 10, 2181, 221));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(verticalLayoutWidget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font1;
        font1.setPointSize(25);
        label_2->setFont(font1);

        verticalLayout_3->addWidget(label_2);

        BtextBrowser = new QTextBrowser(verticalLayoutWidget_3);
        BtextBrowser->setObjectName(QString::fromUtf8("BtextBrowser"));

        verticalLayout_3->addWidget(BtextBrowser);

        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(8, 240, 2181, 541));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font2;
        font2.setPointSize(30);
        label->setFont(font2);

        verticalLayout_2->addWidget(label);

        textBrowser = new QTextBrowser(verticalLayoutWidget_2);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        verticalLayout_2->addWidget(textBrowser);

        UserWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(UserWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 2208, 22));
        UserWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(UserWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        UserWindow->setStatusBar(statusbar);

        retranslateUi(UserWindow);
        QObject::connect(exitButton, SIGNAL(clicked()), UserWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(UserWindow);
    } // setupUi

    void retranslateUi(QMainWindow *UserWindow)
    {
        UserWindow->setWindowTitle(QApplication::translate("UserWindow", "userWindow", nullptr));
        borrowButton->setText(QApplication::translate("UserWindow", "borrow(B)", nullptr));
#ifndef QT_NO_SHORTCUT
        borrowButton->setShortcut(QApplication::translate("UserWindow", "B", nullptr));
#endif // QT_NO_SHORTCUT
        returnButton->setText(QApplication::translate("UserWindow", "return(R)", nullptr));
#ifndef QT_NO_SHORTCUT
        returnButton->setShortcut(QApplication::translate("UserWindow", "R", nullptr));
#endif // QT_NO_SHORTCUT
        exitButton->setText(QApplication::translate("UserWindow", "exit(Esc)", nullptr));
#ifndef QT_NO_SHORTCUT
        exitButton->setShortcut(QApplication::translate("UserWindow", "Esc", nullptr));
#endif // QT_NO_SHORTCUT
        label_2->setText(QApplication::translate("UserWindow", "Borrowed equipment\357\274\232", nullptr));
        label->setText(QApplication::translate("UserWindow", "Available equipment\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UserWindow: public Ui_UserWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERWINDOW_H
