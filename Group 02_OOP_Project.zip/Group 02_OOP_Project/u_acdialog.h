#ifndef U_ACDIALOG_H
#define U_ACDIALOG_H

#include <QDialog>
#include "userc.h"

namespace Ui {
class U_ACDialog;
}

class U_ACDialog : public QDialog
{
    Q_OBJECT

public:
    explicit U_ACDialog(QWidget *parent = nullptr);
    ~U_ACDialog();

private slots:
    void on_changeButton_clicked();

    void on_addButton_clicked();

    void on_deleteButton_clicked();

    void on_changeOKButton_clicked();

    void on_addOKButton_clicked();

    void on_deleteOKButton_clicked();

    void on_changesaveButton_clicked();

    void on_addsaveButton_clicked();

private:
    Ui::U_ACDialog *ui;
};

#endif // U_ACDIALOG_H
