#ifndef STOVE_H
#define STOVE_H
#include "equipmentc.h"

class stove :public equipment {
private:
	QString type;//8
	QString Ftype;//9
	QString Time;//10
	QString borrower;//11
public:
	stove(QString id);
	void settype(QString a);
	void setFtype(QString a);
	void setTime(QString a);
	void setborrower(QString a);

	QString gettype();
	QString getFtype();
	QString getTime();
	QString getborrower();
	void savechange();
	void saveadd();
	void savedel();
};
#endif 
