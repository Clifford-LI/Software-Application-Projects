#include "mainwindow.h"
#include <QApplication>
#include "logindialog.h"
#include "userwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    UserWindow user;
    MainWindow admin;
    LoginDialog dlg;

    if(dlg.exec()==QDialog::Accepted){
        QString ID=dlg.getID();
        if(ID=="admin")
            admin.show();
		else {
			QString Uline = searchData(Ufile, ID);
			QString NAME = "Hello, " +searchPart(Uline, 2);
			QMessageBox::about(NULL, "Welcome", NAME);
			user.setid(ID);
			user.show();
		}  
        return a.exec();
    }
    else
        return 0;

}
