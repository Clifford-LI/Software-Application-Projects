#include "equipmentc.h"
//equipment
equipment::equipment(QString id)  {
	QString Eline = searchData(Efile, id);
	EID = id;
	Name = searchPart(Eline, 2);
	Brand = searchPart(Eline, 3);
	Goods = searchPart(Eline, 4);
	DOP = searchPart(Eline, 5);
	Condition = searchPart(Eline, 6);
	Status = searchPart(Eline, 7);
}
void equipment::setEID(QString a) {
	EID = a;
}
void equipment::setName(QString a) {
	Name = a;
}
void equipment::setBrand(QString a) {
	Brand = a;
}
void equipment::setGoods(QString a) {
	Goods = a;
}
void equipment::setDOP(QString a) {
	DOP = a;
}
void equipment::setCondition(QString a) {
	Condition = a;
}
void equipment::setStatus(QString a) {
	Status = a;
}

QString equipment::getEID() {
	return EID;
}
QString equipment::getName() {
	return Name;
}
QString equipment::getBrand() {
	return Brand;
}
QString equipment::getGoods() {
	return Goods;
}
QString equipment::getDOP() {
	return DOP;
}
QString equipment::getCondition() {
	return Condition;
}
QString equipment::getStatus() {
	return Status;
}


