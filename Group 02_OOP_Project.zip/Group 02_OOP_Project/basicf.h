#ifndef BASICF_H
#define BASICF_H
#include<QString>
#include<QStringList>
#include <QFile>
#include<QTextStream>
#include <QDateTime>

extern QString Efile;
extern QString Ufile;
extern QString Rfile;

QString searchData(QString filename, QString index);
int searchlineN(QString filename, QString index);
QString searchPart(QString target, int index);
QString getAll(QString filename);
int countLines(QString filename);
QString ReadLine(QString filename, int line);
void changeLine(QString filename, int lineN, QString newtext);
void addText(QString filename, int lineN, QString change);
void delLine(QString filename, int lineN);
QString equipDisplay();
QString GetTime();
int Timeinterval(QString time);
int searchrecordN(QString filename, QString UID,QString EID);
QString searchrecord(QString index, int partN);

#endif
