#include "stove.h"
stove::stove(QString id) :equipment(id) {
	QString line = searchData(Efile, getEID());
	type = searchPart(line, 8);
	Ftype = searchPart(line, 9);
	Time = searchPart(line, 10);
	borrower = searchPart(line, 11);
}
void stove::settype(QString a) {
	type = a;
}
void stove::setFtype(QString a) {
	Ftype = a;
}
void stove::setTime(QString a) {
	Time = a;
}
void stove::setborrower(QString a) {
	borrower = a;
}

QString stove::gettype() {
	return type;
}
QString stove::getFtype() {
	return Ftype;
}
QString stove::getTime() {
	return Time;
}
QString stove::getborrower() {
	return borrower;
}
void stove::savechange() {
	QString change = getEID() + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + getStatus() + "|" +type+"|"
		+Ftype+ "|" + Time + "|" + borrower;
	changeLine(Efile, searchlineN(Efile, getEID()), change);
}
void stove::saveadd() {
	int	lineTend = searchlineN(Efile, "S");
	int	lineSend = searchlineN(Efile, "L");
	QString change, id;

	if ((lineSend - lineTend) < 10)
		id = "S00" + QString::number(lineSend - lineTend + 1);
	else if ((lineSend - lineTend) >= 10 && (lineSend - lineTend) < 100)
		id = "S0" + QString::number(lineSend - lineTend + 1);
	else
		id = "S" + QString::number(lineSend - lineTend + 1);

	change = id + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + "in" + "|" + type + "|" + Ftype + "||";
	addText(Efile, lineSend, change);
}
void stove::savedel() {
	QString change, Line, outcome;

	int numberOfLine = searchlineN(Efile, getEID());
	change = getEID() + "|||stove|||in||||";
	changeLine(Efile, numberOfLine, change);
	
}