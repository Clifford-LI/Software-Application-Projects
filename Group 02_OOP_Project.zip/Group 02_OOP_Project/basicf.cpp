#include "basicf.h"
//search and get the whole line of data

QString Efile = "camp_equipment.txt";
QString Ufile = "user.txt";
QString Rfile = "record.txt";

//search the line accord to the begining part of QString
QString searchData(QString filename, QString index) {
    QFile nfile(filename);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream in(&nfile);
    for(int i=0;i<countLines(filename);i++)
	{
		QString str= in.readLine();
        QString indexdata=str.left(index.length());
        if (QString::compare(indexdata,index)==0)
            return str;
    }
    nfile.close();
	return "wrong";
}

//search the line number of data according to the begining part 
int searchlineN(QString filename, QString index) {
    QFile nfile(filename);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
    int count = 1;
    while(!nfile.atEnd())
    {
        QByteArray line = nfile.readLine();
        QString str(line);
        if (str.startsWith(index))
            return count;
        else
            count++;
    }
    nfile.close();
    return 0;
}

//search part of QString according to "|". 
QString searchPart(QString target, int index) {
	QStringList Adata = target.split("|");
	if (Adata.size() >= index){
		QString outcome = Adata.at(index - 1);
		return outcome;
	}
	else
		return "wrong";

}

//get all the data in the file
QString getAll(QString filename) {
	QFile nfile(filename);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
	QByteArray all = nfile.readAll();
	QString	str(all);
	nfile.close();
	return str;
}

//find the lines of file
int countLines(QString filename)
{
	int n = 0;
	QFile nfile(filename);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
	
	while (!nfile.atEnd()) {
		nfile.readLine();
		n++;
		}
		nfile.close();
		return n;
}

//read content of the line accord the line number
QString ReadLine(QString filename, int line)
{
	int lines;
	QString content;
	QFile file(filename);
	lines = countLines(filename);
	file.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream in(&file);

	if (line > lines|| line <= 0)
		return "wrong";
	else {
		for (int i = 0; i < line; i++) {
			QString str = in.readLine();
			content = str;
		}
	}
	file.close();
	return content;
}

//change the data of line
void changeLine(QString filename, int lineN, QString newtext) {
	
	int a = countLines(filename);
	QString data = "";
	for (int i = 1; i <= a; i++) {
		if (i != lineN) {
			data += ReadLine(filename, i);
			data+= "\r\n";
		}
		else {
			data += newtext;
			data += "\r\n";
		}
	}
	QFile outfile(filename);
	outfile.open(QIODevice::WriteOnly);
	QTextStream out(&outfile);
	out << data;
	outfile.close();
}

//add a line of text according to the line number
void addText(QString filename, int lineN, QString change) {
    QString data;
    for (int i = 1; i < lineN; i++) {
        data += ReadLine(filename, i);
		data += "\r\n";
    }
    data += change;
	data += "\r\n";
    for (int i = lineN ; i <= countLines(filename); i++) {
		QString C=ReadLine(filename, i);
		if(!C.startsWith("wrong")){
        data += C;
		data += "\r\n";
		}
    }
    QFile outfile(filename);
    outfile.open(QIODevice::WriteOnly);
    QTextStream out(&outfile);
    out << data;
    outfile.close();
}

//del the line
void delLine(QString filename, int lineN) {
    QString data;
    for (int i = 1; i <= countLines(filename); i++) {
        if (i != lineN) {
            data += ReadLine(filename, i);
			data += "\r\n";
        }
    }
    QFile outfile(filename);
    outfile.open(QIODevice::WriteOnly);
    QTextStream out(&outfile);
    out << data;
    outfile.close();
}

//get all the good and in equipment
QString equipDisplay() {
	QString str="";
	QFile nfile(Efile);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream in(&nfile);
	while (!nfile.atEnd()) {
		QString line = nfile.readLine();
		if (searchPart(line, 6) == "good" && searchPart(line, 7) == "in") {
			str += line;
		}
	}
	nfile.close();
	return str;		
}

//get time
QString GetTime(){
QDateTime Time=QDateTime::currentDateTime();
QString time = Time.toString("ddMMyyyy");
return time;
}

//timeinterval
int Timeinterval(QString time) {
	QDateTime start = QDateTime::fromString(time, "ddMMyyyy");
	QDateTime end=QDateTime::currentDateTime();
	uint stime = start.toTime_t();
	uint etime = end.toTime_t();
	double Sec=difftime(stime, etime);
	int ndaysec = 24 * 60 * 60;
	int diff = (int)Sec / (ndaysec)+((int)Sec % (ndaysec)+(ndaysec - 1)) / (ndaysec);
	return diff;
}

//search record file according to the given message and get the line number
int searchrecordN(QString filename, QString UID, QString EID) {
QFile nfile(filename);
nfile.open(QIODevice::ReadOnly | QIODevice::Text);
int count = 1;
while (!nfile.atEnd())
{
	QByteArray line = nfile.readLine();
	QString str(line);
	if (str.startsWith(UID)&&searchPart(str,3).startsWith(EID)&&searchPart(str, 7).startsWith(""))
		return count;
	else
		count++;
}
nfile.close();
return 0;
}

//find all the data in record accord to index and part number
QString searchrecord( QString index, int partN) {
	QString str = "";
	QFile nfile(Rfile);
	nfile.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream in(&nfile);
	while (!nfile.atEnd()) {
		QString line = nfile.readLine();
		if (searchPart(line, partN).startsWith(index)) {
			str += line;
		}
	}
	nfile.close();
	return str;
}