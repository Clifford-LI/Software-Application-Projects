#include "lantern.h"

lantern::lantern(QString id):equipment(id) {
	QString line = searchData(Efile, getEID());
	usage= searchPart(line, 8);
	type = searchPart(line, 9);
	Ftype = searchPart(line, 10);
	Time = searchPart(line, 11);
	borrower = searchPart(line, 12);
}
void lantern::setusage(QString a) {
	usage= a;
}
void lantern::settype(QString a) {
	type = a;
}
void lantern::setFtype(QString a) {
	Ftype = a;
}
void lantern::setTime(QString a) {
	Time = a;
}
void lantern::setborrower(QString a) {
	borrower = a;
}

QString lantern::getusage() {
	return usage;
}
QString lantern::gettype() {
	return type;
}
QString lantern::getFtype() {
	return Ftype;
}
QString lantern::getTime() {
	return Time;
}
QString lantern::getborrower() {
	return borrower;
}
void lantern::savechange() {
	QString change = getEID() + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + getStatus() + "|" + usage + "|" + type + "|"
		+ Ftype + "|" + Time + "|" + borrower;
	changeLine(Efile, searchlineN(Efile, getEID()), change);
}
void lantern::saveadd() {
	QString change, id;
	int	lineSend = searchlineN(Efile, "L");
	int lineLend = countLines(Efile);
	if ((lineLend - lineSend + 2) < 10)
		id = "L00" + QString::number(lineLend - lineSend + 2);
	else if (lineLend >= 10 && lineLend < 100)
		id = "L0" + QString::number(lineLend - lineSend + 2);
	else
		id = "L" + QString::number(lineLend - lineSend + 2);
		
	change = id + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + getStatus() + "|" + usage + "|" + type + "|"
		+ Ftype + "|" + "|";
	addText(Efile, lineLend + 1, change);

}
void lantern::savedel() {
	QString change;

	int numberOfLine = searchlineN(Efile, getEID());
	change = getEID() + "|||lantern|||in|||||";
	changeLine(Efile, numberOfLine, change);
}