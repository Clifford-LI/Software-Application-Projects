#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QInputDialog>
#include <QMessageBox>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_userDpushButton_clicked();

    void on_equipmentDpushButton_clicked();

    void on_backDpushButton_clicked();

    void on_EFButton_clicked();

    void on_UFButton_clicked();

    void on_recordButton_clicked();

    void on_searchButton_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
