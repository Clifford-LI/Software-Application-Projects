#ifndef TENT_H
#define TENT_H
#include "equipmentc.h"

class tent :public equipment {
private:
	QString ppl;//8
	QString type;//9
	QString door;//10
	QString DL;//11
	QString Colour;//12
	QString Time;//13
	QString borrower;//14
public:
	tent(QString id);
	void setppl(QString a);
	void settype(QString a);
	void setdoor(QString a);
	void setDL(QString a);
	void setColour(QString a);
	void setTime(QString a);
	void setborrower(QString a);

	QString getppl();
	QString gettype();
	QString getdoor();
	QString getDL();
	QString getColour();
	QString getTime();
	QString getborrower();
	void savechange();
	void saveadd();
	void savedel();
};
#endif 

