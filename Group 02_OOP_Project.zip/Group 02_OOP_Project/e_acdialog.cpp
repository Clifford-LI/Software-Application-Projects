﻿#include "e_acdialog.h"
#include "ui_e_acdialog.h"
#include "basicf.h"
#include "QMessageBox"



E_ACDialog::E_ACDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::E_ACDialog)
{
    ui->setupUi(this);

    ui->IDlabel->setVisible(false);
    ui->IDcomboBox->setVisible(false);
    ui->IDtextEdit->setVisible(false);

    ui->namelabel->setVisible(false);
    ui->nametextEdit->setVisible(false);

    ui->brandlabel->setVisible(false);
    ui->brandtextEdit->setVisible(false);

    ui->DOBlabel->setVisible(false);
    ui->DOBtextEdit->setVisible(false);

    ui->condationlabel->setVisible(false);
    ui->conditioncomboBox->setVisible(false);

	ui->ppllabel->setVisible(false);
	ui->ppltextEdit->setVisible(false);

	ui->doorlabel->setVisible(false);
	ui->doortextEdit->setVisible(false);

	ui->usagelabel->setVisible(false);
	ui->usagecomboBox->setVisible(false);

    ui->typelabel->setVisible(false);
    ui->typetextEdit->setVisible(false);

    ui->DLlabel->setVisible(false);
    ui->DLcomboBox->setVisible(false);

    ui->colourlabel->setVisible(false);
    ui->colourtextEdit->setVisible(false);

    ui->Ftypelabel->setVisible(false);
    ui->FtypetextEdit->setVisible(false);

    ui->changeOKButton->setVisible(false);
    ui->addOKButton->setVisible(false);
	ui->deleteOKButton->setVisible(false);

	ui->changesaveButton->setVisible(false);
    ui->addsaveButton->setVisible(false);
}

E_ACDialog::~E_ACDialog()
{
    delete ui;
}

//ADD
void E_ACDialog::on_addButton_clicked()
{
     ui->IDlabel->setVisible(true);
     ui->IDcomboBox->setVisible(true);

     ui->addOKButton->setVisible(true);
	 ui->changeOKButton->setVisible(false);

	 ui->changeButton->setVisible(false);
	 ui->deleteButton->setVisible(false);
	 ui->addButton->setVisible(false);
}

void E_ACDialog::on_addOKButton_clicked()
{
    QString ID=ui->IDcomboBox->currentText();

	ui->addOKButton->setVisible(false);
	ui->IDlabel->setVisible(false);
	ui->IDtextEdit->setVisible(false);
	ui->IDcomboBox->setEnabled(false);

    if(QString::compare(ID,"tent")==0){
        ui->namelabel->setVisible(true);
        ui->nametextEdit->setVisible(true);

        ui->brandlabel->setVisible(true);
        ui->brandtextEdit->setVisible(true);

        ui->DOBlabel->setVisible(true);
        ui->DOBtextEdit->setVisible(true);

        ui->condationlabel->setVisible(true);
		ui->conditioncomboBox->setVisible(true);

		ui->ppllabel->setVisible(true);
		ui->ppltextEdit->setVisible(true);

		ui->doorlabel->setVisible(true);
		ui->doortextEdit->setVisible(true);

        ui->typelabel->setVisible(true);
        ui->typetextEdit->setVisible(true);

        ui->DLlabel->setVisible(true);
        ui->DLcomboBox->setVisible(true);

        ui->colourlabel->setVisible(true);
        ui->colourtextEdit->setVisible(true);

		ui->changesaveButton->setVisible(false);
        ui->addsaveButton->setVisible(true);
    }
    else{
        ui->namelabel->setVisible(true);
        ui->nametextEdit->setVisible(true);

        ui->brandlabel->setVisible(true);
        ui->brandtextEdit->setVisible(true);

        ui->DOBlabel->setVisible(true);
        ui->DOBtextEdit->setVisible(true);

        ui->condationlabel->setVisible(true);
		ui->conditioncomboBox->setVisible(true);

		ui->usagelabel->setVisible(true);
		ui->usagecomboBox->setVisible(true);

        ui->typelabel->setVisible(true);
        ui->typetextEdit->setVisible(true);

        ui->Ftypelabel->setVisible(true);
        ui->FtypetextEdit->setVisible(true);

		ui->changesaveButton->setVisible(false);
        ui->addsaveButton->setVisible(true);
    }
}

void E_ACDialog::on_addsaveButton_clicked()
{
    QString ID=ui->IDcomboBox->currentText();
    
    if(ID.startsWith("t")){
		tent T(ID);
		T.setName(ui->nametextEdit->text());
		T.setBrand(ui->brandtextEdit->text());
		T.setDOP(ui->DOBtextEdit->text());
		T.setCondition(ui->conditioncomboBox->currentText());
		T.setGoods("tent");
		T.setStatus("in");
		T.setppl(ui->ppltextEdit->text());
		T.settype(ui->typetextEdit->text());
		T.setdoor(ui->doortextEdit->text());
		T.setDL(ui->DLcomboBox->currentText());
		T.setColour(ui->colourtextEdit->text());
		T.saveadd();
    }
    else if(ID.startsWith("s")){
		stove S("S");
		S.setName(ui->nametextEdit->text());
		S.setBrand(ui->brandtextEdit->text());
		S.setDOP(ui->DOBtextEdit->text());
		S.setCondition(ui->conditioncomboBox->currentText());
		S.setGoods("stove");
		S.setStatus("in");
		S.settype(ui->typetextEdit->text());
		S.setFtype(ui->FtypetextEdit->text());
		S.saveadd();
    }
    else{
		lantern L("L");
		L.setName(ui->nametextEdit->text());
		L.setBrand(ui->brandtextEdit->text());
		L.setDOP(ui->DOBtextEdit->text());
		L.setCondition(ui->conditioncomboBox->currentText());
		L.setGoods("stove");
		L.setStatus("in");
		L.settype(ui->typetextEdit->text());
		L.setFtype(ui->FtypetextEdit->text());
		L.saveadd();
    }

}


//CHANGE
void E_ACDialog::on_changeButton_clicked()
{
    ui->IDlabel->setVisible(true);
    ui->IDtextEdit->setVisible(true);

	ui->changeOKButton->setVisible(true);
    ui->addOKButton->setVisible(false);

    ui->changeButton->setVisible(false);
    ui->deleteButton->setVisible(false);
    ui->addButton->setVisible(false);
    
}

void E_ACDialog::on_changeOKButton_clicked()
{
    QString ID=ui->IDtextEdit->text();
	QString Eline=searchData(Efile, ID);
	if (QString::compare(Eline, "wrong") == 0||ID.length()!=4) {
		ui->IDtextEdit->clear();
		QMessageBox::warning(this, tr("warning!"), tr("Wrong!"), QMessageBox::Ok);
		ui->IDlabel->setVisible(true);
		ui->IDtextEdit->setVisible(true);

		ui->changeOKButton->setVisible(true);
		ui->addOKButton->setVisible(false);

		ui->changeButton->setVisible(false);
		ui->deleteButton->setVisible(false);
		ui->addButton->setVisible(false);

	}
	else {

		ui->addButton->setVisible(false);
		ui->changeButton->setVisible(false);
		ui->deleteButton->setVisible(false);

		ui->addOKButton->setVisible(false);
		ui->changeOKButton->setVisible(false);

		ui->IDlabel->setVisible(false);
		ui->IDtextEdit->setEnabled(false);
		ui->IDcomboBox->setVisible(false);


		if (ID.startsWith("T")) {
			tent T(ID);
			ui->namelabel->setVisible(true);
			ui->nametextEdit->setVisible(true);
			ui->nametextEdit->setText(T.getName());

			ui->brandlabel->setVisible(true);
			ui->brandtextEdit->setVisible(true);
			ui->brandtextEdit->setText(T.getBrand());

			ui->DOBlabel->setVisible(true);
			ui->DOBtextEdit->setVisible(true);
			ui->DOBtextEdit->setText(T.getDOP());

			ui->condationlabel->setVisible(true);
			ui->conditioncomboBox->setVisible(true);
			if (T.getCondition().compare("good") == 0) {
				ui->conditioncomboBox->setCurrentIndex(0);
			}
			else if (T.getCondition().compare("being repaired") == 0) {
				ui->conditioncomboBox->setCurrentIndex(1);
			}
			else if (T.getCondition().compare("damaged") == 0) {
				ui->conditioncomboBox->setCurrentIndex(2);
			}
			else {
				ui->conditioncomboBox->setCurrentIndex(3);
			}

			ui->ppllabel->setVisible(true);
			ui->ppltextEdit->setVisible(true);
			ui->ppltextEdit->setText(T.getppl());

			ui->typelabel->setVisible(true);
			ui->typetextEdit->setVisible(true);
			ui->typetextEdit->setText(T.gettype());

			ui->doorlabel->setVisible(true);
			ui->doortextEdit->setVisible(true);
			ui->doortextEdit->setText(T.getdoor());

			ui->DLlabel->setVisible(true);
			ui->DLcomboBox->setVisible(true);
			if (T.getDL().compare("true") == 0) {
				ui->DLcomboBox->setCurrentIndex(0);
			}
			else {
				ui->DLcomboBox->setCurrentIndex(1);
			}

			ui->colourlabel->setVisible(true);
			ui->colourtextEdit->setVisible(true);
			ui->colourtextEdit->setText(T.getColour());

			ui->addsaveButton->setVisible(false);
			ui->changesaveButton->setVisible(true);
		}
		else if (ID.startsWith("S")) {
			stove S(ID);
			ui->namelabel->setVisible(true);
			ui->nametextEdit->setVisible(true);
			ui->nametextEdit->setText(S.getName());

			ui->brandlabel->setVisible(true);
			ui->brandtextEdit->setVisible(true);
			ui->brandtextEdit->setText(S.getBrand());

			ui->DOBlabel->setVisible(true);
			ui->DOBtextEdit->setVisible(true);
			ui->DOBtextEdit->setText(S.getDOP());

			ui->condationlabel->setVisible(true);
			ui->conditioncomboBox->setVisible(true);
			if (S.getCondition().compare("good") == 0) {
				ui->conditioncomboBox->setCurrentIndex(0);
			}
			else if (S.getCondition().compare("being repaired") == 0) {
				ui->conditioncomboBox->setCurrentIndex(1);
			}
			else if (S.getCondition().compare("damaged") == 0) {
				ui->conditioncomboBox->setCurrentIndex(2);
			}
			else {
				ui->conditioncomboBox->setCurrentIndex(3);
			}

			ui->typelabel->setVisible(true);
			ui->typetextEdit->setVisible(true);
			ui->typetextEdit->setText(S.gettype());

			ui->Ftypelabel->setVisible(true);
			ui->FtypetextEdit->setVisible(true);
			ui->FtypetextEdit->setText(S.getFtype());

			ui->addsaveButton->setVisible(false);
			ui->changesaveButton->setVisible(true);
		}
		else if (ID.startsWith("L")) {
			lantern L(ID);
			ui->namelabel->setVisible(true);
			ui->nametextEdit->setVisible(true);
			ui->nametextEdit->setText(L.getName());

			ui->brandlabel->setVisible(true);
			ui->brandtextEdit->setVisible(true);
			ui->brandtextEdit->setText(L.getBrand());

			ui->DOBlabel->setVisible(true);
			ui->DOBtextEdit->setVisible(true);
			ui->DOBtextEdit->setText(L.getDOP());

			ui->condationlabel->setVisible(true);
			ui->conditioncomboBox->setVisible(true);
			if (L.getCondition().compare("good") == 0) {
				ui->conditioncomboBox->setCurrentIndex(0);
			}
			else if (L.getCondition().compare("being repaired") == 0) {
				ui->conditioncomboBox->setCurrentIndex(1);
			}
			else if (L.getCondition().compare("damaged") == 0) {
				ui->conditioncomboBox->setCurrentIndex(2);
			}
			else {
				ui->conditioncomboBox->setCurrentIndex(3);
			}


			ui->usagelabel->setVisible(true);
			ui->usagecomboBox->setVisible(true);
			if (L.getusage().compare("hiking") == 0) {
				ui->usagecomboBox->setCurrentIndex(0);
			}
			else {
				ui->usagecomboBox->setCurrentIndex(1);
			}

			ui->typelabel->setVisible(true);
			ui->typetextEdit->setVisible(true);
			ui->typetextEdit->setText(L.gettype());

			ui->Ftypelabel->setVisible(true);
			ui->FtypetextEdit->setVisible(true);
			ui->FtypetextEdit->setText(L.getFtype());

			ui->addsaveButton->setVisible(false);
			ui->changesaveButton->setVisible(true);
		}
		else {
			ui->IDtextEdit->clear();
			QMessageBox::warning(this, tr("warning!"), tr("wrong!"), QMessageBox::Ok);
		}
	}
}

void E_ACDialog::on_changesaveButton_clicked()
{

    QString ID=ui->IDtextEdit->text();
	if (ID.startsWith("T")) {
		tent T(ID);
		T.setName(ui->nametextEdit->text());
		T.setBrand(ui->brandtextEdit->text());
		T.setDOP(ui->DOBtextEdit->text());
		T.setCondition(ui->conditioncomboBox->currentText());
		T.setppl(ui->ppltextEdit->text());
		T.settype(ui->typetextEdit->text());
		T.setdoor(ui->doortextEdit->text());
		T.setDL(ui->DLcomboBox->currentText());
		T.setColour(ui->colourtextEdit->text());
		T.savechange();
    }
    else if(ID.startsWith("S")){
		stove S(ID);
		S.setName(ui->nametextEdit->text());
		S.setBrand(ui->brandtextEdit->text());
		S.setDOP(ui->DOBtextEdit->text());
		S.setCondition(ui->conditioncomboBox->currentText());
		S.settype(ui->typetextEdit->text());
		S.setFtype(ui->FtypetextEdit->text());
		S.savechange();    
    }
    else{
		lantern L(ID);
		L.setName(ui->nametextEdit->text());
		L.setBrand(ui->brandtextEdit->text());
		L.setDOP(ui->DOBtextEdit->text());
		L.setCondition(ui->conditioncomboBox->currentText());
		L.setusage(ui->usagecomboBox->currentText());
		L.settype(ui->typetextEdit->text());
		L.setFtype(ui->FtypetextEdit->text());
		L.savechange();
    }
}


//deldte
void E_ACDialog::on_deleteButton_clicked()
{
    ui->IDlabel->setVisible(true);
    ui->IDtextEdit->setVisible(true);
    ui->deleteOKButton->setVisible(true);
    ui->addButton->setVisible(false);
    ui->changeButton->setVisible(false);
    ui->deleteButton->setVisible(false);
}

void E_ACDialog::on_deleteOKButton_clicked()
{
    QString ID=ui->IDtextEdit->text();

	int numberLine = searchlineN(Efile, ID);

	if (numberLine==0||ID.length()!=4) {
		ui->IDtextEdit->clear();
		QMessageBox::warning(this, tr("warning!"), tr("ID is incorrect!"), QMessageBox::Ok);
	}
	else {
		if (ID.startsWith("T")) {
			tent T(ID);
			T.savedel();
		}
		//STOVE
		else if (ID.startsWith("S")) {
			stove S(ID);
			S.savedel();
		}
		//lanten
		else{
			lantern L(ID);
			L.savedel();
			}
		}
	}

