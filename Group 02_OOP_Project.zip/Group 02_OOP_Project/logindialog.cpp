#include "logindialog.h"
#include "ui_logindialog.h"
#include "basicf.h"
#include <QMessageBox>
#include <QFile>


LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
	ui->userlineEdit->setFocus();
}

LoginDialog::~LoginDialog()
{
    delete ui;
}


void LoginDialog::on_loginpushButton_clicked()
{
	

   userID=ui->userlineEdit->text();
   QString password=ui->passwordlineEdit->text();

   //find the password according the input id
    QString idValidate = searchData(Ufile, userID);
    QString passValidate = searchPart(idValidate, 4);

	
	QWidget::setTabOrder(ui->userlineEdit, ui->passwordlineEdit);
	QWidget::setTabOrder(ui->passwordlineEdit, ui->loginpushButton);
	QWidget::setTabOrder(ui->loginpushButton, ui->exitpushButton);
	QWidget::setTabOrder(ui->exitpushButton, ui->userlineEdit);

	//judge if user can login or not
    if(userID==tr("admin")&&password==tr("admin")){
       accept();
    }
    else if (QString::compare(passValidate, password) == 0 && userID.length() == 6) {
       accept();
    }
    else{
        QMessageBox::warning(this,tr("warning!"),tr("Please enter correct User ID or password!"),QMessageBox::Ok);
        //clean the lineedit and refocus the mouse
        ui->userlineEdit->clear();
        ui->passwordlineEdit->clear();
        ui->userlineEdit->setFocus();
    }
}
QString LoginDialog::getID() {
	return userID;
}



