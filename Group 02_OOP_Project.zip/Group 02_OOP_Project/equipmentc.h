#ifndef EQUIPMENTC_H
#define EQUIPMENTC_H

#include "basicf.h"

class equipment {
private:
	QString EID;//1
	QString Name;//2
	QString Brand;//3
	QString Goods;//4
	QString DOP;//5
	QString Condition;//6
	QString Status;//7
public:
	equipment(QString id);
	void setEID(QString a);
	void setName(QString a);
	void setBrand(QString a);
	void setGoods(QString a);
	void setDOP(QString a);
	void setCondition(QString a);
	void setStatus(QString a);

	QString getEID();
	QString getName();
	QString getBrand();
	QString getGoods();
	QString getDOP();
	QString getCondition();
	QString getStatus();

	virtual void savechange() = 0;
	virtual void saveadd() = 0;
	virtual void savedel() = 0;
};



#endif
