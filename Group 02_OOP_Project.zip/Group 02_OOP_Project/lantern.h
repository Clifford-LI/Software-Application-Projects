#ifndef LANTERN_H
#define LANTERN_H
#include "equipmentc.h"

class lantern :public equipment {
private:
	QString usage;//8
	QString type;//9
	QString Ftype;//10
	QString Time;//11
	QString borrower;//12
public:
	lantern(QString id);
	void setusage(QString a);
	void settype(QString a);
	void setFtype(QString a);
	void setTime(QString a);
	void setborrower(QString a);

	QString getusage();
	QString gettype();
	QString getFtype();
	QString getTime();
	QString getborrower();
	void savechange();
	void saveadd();
	void savedel();
};
#endif 
