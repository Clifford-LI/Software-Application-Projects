#include "userwindow.h"
#include "ui_userwindow.h"

UserWindow::UserWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UserWindow)
{
    ui->setupUi(this);
    ui->textBrowser->setText(equipDisplay());
}

UserWindow::~UserWindow()
{
    delete ui;
}

void UserWindow::setid(QString Id) {
	id = Id;
	User l(id);
	ui->borrowButton->setVisible(l.judgeBorrow());
	ui->BtextBrowser->setText(l.GoodsOfBorrow());
}

void UserWindow::on_borrowButton_clicked()
{
	User M(id);
	bool ok;
	QString text = QInputDialog::getText(this, tr("Borrow"),
		tr("ID: "), QLineEdit::Normal,nullptr,&ok);
	if (ok) {
		QString line = searchData(Efile, text);
		if (!M.judgeBorrow()) {
			QMessageBox::information(NULL, "notice", "Borrow upto max");
		}
		else if (line.compare("wrong") == 0 || text.length() != 4 || searchPart(line, 7).compare("out") == 0 || searchPart(line, 6).compare("good")!=0) {
			QMessageBox::information(NULL, "notice", "wrong");
		}

		else {
			QMessageBox::information(NULL, "bingo", searchData(Efile, text));
			QString line = searchData(Efile, text);
			line = line.left(line.length() - 1);
			line = line + GetTime() + "|" + id;
			QString change;
			if (text.startsWith("T")) {
				change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
					"|" + searchPart(line, 6) + "|" + "out" + "|" + searchPart(line, 8) + "|" +
					searchPart(line, 9) + "|" + searchPart(line, 10) + "|" + searchPart(line, 11) + "|" +
					searchPart(line, 12) + "|" + searchPart(line, 13) + "|" + searchPart(line, 14);
			}
			else if (text.startsWith("S")) {

				change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
					"|" + searchPart(line, 6) + "|" + "out" + "|" + searchPart(line, 8) + "|" +
					searchPart(line, 9) + "|" + searchPart(line, 10) + "|" + searchPart(line, 11);

			}
			else {

				change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
					"|" + searchPart(line, 6) + "|" + "out" + "|" + searchPart(line, 8) + "|" +
					searchPart(line, 9) + "|" + searchPart(line, 10) + "|" + searchPart(line, 11) + "|" + searchPart(line, 12);
			}
			changeLine(Efile, searchlineN(Efile, text), change);
			QString record=id + "|" + M.getName() + "|" + text + "|" + searchPart(line, 2) + "|"+ GetTime()+"|"+"out"+"|";
			addText(Rfile, 0, record);
		}
	}
	ui->textBrowser->setText(equipDisplay());
	ui->borrowButton->setVisible(M.judgeBorrow());
	ui->BtextBrowser->setText(M.GoodsOfBorrow());
}

void UserWindow::on_returnButton_clicked()
{
	bool ok;
	User N(id);
	QString text = QInputDialog::getText(this, tr("Return"),
		tr("ID: "), QLineEdit::Normal,nullptr, &ok);
	if (ok) {
		QString AllLine = N.GoodsOfBorrow();
		QStringList list = AllLine.split("\n");
		for (int i = 0; i < list.count(); i++) {
			QString line = list.at(i);
			if (!line.startsWith(text) || text.length() != 4) {
				if (i == list.count() - 1)
					QMessageBox::information(NULL, "notice", "wrong");
			}
			else {
				line = line.left(line.length() - 1);
				QString change;
				if (text.startsWith("T")) {
					change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
						"|" + searchPart(line, 6) + "|" + "in" + "|" + searchPart(line, 8) + "|" +
						searchPart(line, 9) + "|" + searchPart(line, 10) + "|" + searchPart(line, 11) + "|" +
						searchPart(line, 12) + "|" + "|";
				}
				else if (text.startsWith("S")) {

					change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
						"|" + searchPart(line, 6) + "|" + "in" + "|" + searchPart(line, 8) + "|" +
						searchPart(line, 9) + "|" + "|";

				}
				else {

					change = text + "|" + searchPart(line, 2) + "|" + searchPart(line, 3) + "|" + searchPart(line, 4) + "|" + searchPart(line, 5) +
						"|" + searchPart(line, 6) + "|" + "in" + "|" + searchPart(line, 8) + "|" +
						searchPart(line, 9) + "|" + searchPart(line, 10) + "|" + "|";
				}
				changeLine(Efile, searchlineN(Efile, text), change);
				int LineN = searchrecordN(Rfile, id, text);
				QString record = ReadLine(Rfile, LineN);
				record= searchPart(record, 1) + "|" + searchPart(record, 2) + "|" + searchPart(record, 3) + "|" +
					searchPart(record, 4) +"|" + searchPart(record, 5)+"|"+"returned"+"|" + GetTime();
				changeLine(Rfile, LineN, record);
				ui->borrowButton->setVisible(true);
				break;
			}
		}
	}
	ui->BtextBrowser->setText(N.GoodsOfBorrow());
	ui->textBrowser->setText(equipDisplay());
}

