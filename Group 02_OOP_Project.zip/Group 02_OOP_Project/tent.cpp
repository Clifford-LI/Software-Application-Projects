#include "tent.h"

tent::tent(QString id):equipment(id) {
	QString line = searchData(Efile, getEID());
	ppl = searchPart(line, 8);
	type = searchPart(line, 9);
	door = searchPart(line, 10);
	DL = searchPart(line, 11);
	Colour = searchPart(line, 12);
	Time = searchPart(line, 13);
	borrower = searchPart(line, 14);
}
void tent::setppl(QString a) {
	ppl = a;
}
void tent::settype(QString a) {
	type = a;
}
void tent::setdoor(QString a) {
	door = a;
}
void tent::setDL(QString a) {
	DL = a;
}
void tent::setColour(QString a) {
	Colour = a;
}
void tent::setTime(QString a) {
	Time = a;
}
void tent::setborrower(QString a) {
	borrower = a;
}

QString tent::getppl() {
	return ppl;
}
QString tent::gettype() {
	return type;
}
QString tent::getdoor() {
	return door;
}
QString tent::getDL() {
	return DL;
}
QString tent::getColour() {
	return Colour;
}
QString tent::getTime() {
	return Time;
}
QString tent::getborrower() {
	return borrower;
}
void tent::savechange() {
	QString change = getEID() + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + getStatus() + "|" + ppl + "|" +
		type + "|" + door + "|" + DL + "|" + Colour + "|" + Time + "|" + borrower;
	changeLine(Efile, searchlineN(Efile, getEID()), change);
}

void tent::saveadd() {
	int	lineTend = searchlineN(Efile, "S");
	QString id,change;
	if (lineTend < 10)
		id = "T00" + QString::number(lineTend);
	else if (lineTend >= 10 && lineTend < 100)
		id = "T0" + QString::number(lineTend);
	else
		id = "T" + QString::number(lineTend);

	change = id + "|" + getName() + "|" + getBrand() + "|" + getGoods() +
		"|" + getDOP() + "|" + getCondition() + "|" + getStatus() + "|" + ppl + "|" +
		type + "|" + door + "|" + DL + "|" + Colour + "||";
	addText(Efile, lineTend, change);
}

void tent::savedel() {
	QString change;
	int numberOfLine = searchlineN(Efile, getEID());
	change = getEID() + "|||tent|||in|||||||";
	changeLine(Efile, numberOfLine, change);
}