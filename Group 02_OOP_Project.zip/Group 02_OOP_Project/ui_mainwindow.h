/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionchange;
    QAction *actionadd;
    QAction *actiondelet;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QLabel *equipmentlabel;
    QLabel *userlabel;
    QLabel *recordlabel;
    QTextBrowser *textBrowser;
    QPushButton *equipmentDpushButton;
    QPushButton *EFButton;
    QPushButton *userDpushButton;
    QPushButton *UFButton;
    QPushButton *recordButton;
    QPushButton *searchButton;
    QPushButton *backDpushButton;
    QPushButton *ExitButton;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1942, 989);
        actionchange = new QAction(MainWindow);
        actionchange->setObjectName(QString::fromUtf8("actionchange"));
        actionadd = new QAction(MainWindow);
        actionadd->setObjectName(QString::fromUtf8("actionadd"));
        actiondelet = new QAction(MainWindow);
        actiondelet->setObjectName(QString::fromUtf8("actiondelet"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        equipmentlabel = new QLabel(centralWidget);
        equipmentlabel->setObjectName(QString::fromUtf8("equipmentlabel"));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        font.setWeight(75);
        equipmentlabel->setFont(font);
        equipmentlabel->setContextMenuPolicy(Qt::DefaultContextMenu);

        verticalLayout->addWidget(equipmentlabel);

        userlabel = new QLabel(centralWidget);
        userlabel->setObjectName(QString::fromUtf8("userlabel"));
        userlabel->setFont(font);

        verticalLayout->addWidget(userlabel);

        recordlabel = new QLabel(centralWidget);
        recordlabel->setObjectName(QString::fromUtf8("recordlabel"));
        recordlabel->setFont(font);

        verticalLayout->addWidget(recordlabel);

        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        verticalLayout->addWidget(textBrowser);

        equipmentDpushButton = new QPushButton(centralWidget);
        equipmentDpushButton->setObjectName(QString::fromUtf8("equipmentDpushButton"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(20);
        font1.setBold(false);
        font1.setWeight(50);
        equipmentDpushButton->setFont(font1);
        equipmentDpushButton->setCheckable(false);

        verticalLayout->addWidget(equipmentDpushButton);

        EFButton = new QPushButton(centralWidget);
        EFButton->setObjectName(QString::fromUtf8("EFButton"));
        QFont font2;
        font2.setPointSize(25);
        font2.setBold(true);
        font2.setWeight(75);
        EFButton->setFont(font2);

        verticalLayout->addWidget(EFButton);

        userDpushButton = new QPushButton(centralWidget);
        userDpushButton->setObjectName(QString::fromUtf8("userDpushButton"));
        userDpushButton->setFont(font2);

        verticalLayout->addWidget(userDpushButton);

        UFButton = new QPushButton(centralWidget);
        UFButton->setObjectName(QString::fromUtf8("UFButton"));
        UFButton->setFont(font2);

        verticalLayout->addWidget(UFButton);

        recordButton = new QPushButton(centralWidget);
        recordButton->setObjectName(QString::fromUtf8("recordButton"));
        recordButton->setFont(font2);

        verticalLayout->addWidget(recordButton);

        searchButton = new QPushButton(centralWidget);
        searchButton->setObjectName(QString::fromUtf8("searchButton"));
        searchButton->setFont(font2);

        verticalLayout->addWidget(searchButton);

        backDpushButton = new QPushButton(centralWidget);
        backDpushButton->setObjectName(QString::fromUtf8("backDpushButton"));
        backDpushButton->setFont(font1);
        backDpushButton->setAutoFillBackground(false);

        verticalLayout->addWidget(backDpushButton);

        ExitButton = new QPushButton(centralWidget);
        ExitButton->setObjectName(QString::fromUtf8("ExitButton"));
        QFont font3;
        font3.setPointSize(20);
        font3.setBold(true);
        font3.setWeight(75);
        ExitButton->setFont(font3);

        verticalLayout->addWidget(ExitButton);

        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(ExitButton, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        actionchange->setText(QApplication::translate("MainWindow", "change", nullptr));
        actionadd->setText(QApplication::translate("MainWindow", "add", nullptr));
        actiondelet->setText(QApplication::translate("MainWindow", "delete", nullptr));
        equipmentlabel->setText(QApplication::translate("MainWindow", "equipment\357\274\232", nullptr));
        userlabel->setText(QApplication::translate("MainWindow", "user\357\274\232", nullptr));
        recordlabel->setText(QApplication::translate("MainWindow", "record\357\274\232", nullptr));
        equipmentDpushButton->setText(QApplication::translate("MainWindow", "equipment\357\274\210E\357\274\211", nullptr));
#ifndef QT_NO_SHORTCUT
        equipmentDpushButton->setShortcut(QApplication::translate("MainWindow", "E", nullptr));
#endif // QT_NO_SHORTCUT
        EFButton->setText(QApplication::translate("MainWindow", "function(F)", nullptr));
#ifndef QT_NO_SHORTCUT
        EFButton->setShortcut(QApplication::translate("MainWindow", "F", nullptr));
#endif // QT_NO_SHORTCUT
        userDpushButton->setText(QApplication::translate("MainWindow", "user\357\274\210U\357\274\211", nullptr));
#ifndef QT_NO_SHORTCUT
        userDpushButton->setShortcut(QApplication::translate("MainWindow", "U", nullptr));
#endif // QT_NO_SHORTCUT
        UFButton->setText(QApplication::translate("MainWindow", "function(F)", nullptr));
#ifndef QT_NO_SHORTCUT
        UFButton->setShortcut(QApplication::translate("MainWindow", "F", nullptr));
#endif // QT_NO_SHORTCUT
        recordButton->setText(QApplication::translate("MainWindow", "record(R)", nullptr));
#ifndef QT_NO_SHORTCUT
        recordButton->setShortcut(QApplication::translate("MainWindow", "R", nullptr));
#endif // QT_NO_SHORTCUT
        searchButton->setText(QApplication::translate("MainWindow", "search(S)", nullptr));
#ifndef QT_NO_SHORTCUT
        searchButton->setShortcut(QApplication::translate("MainWindow", "S", nullptr));
#endif // QT_NO_SHORTCUT
        backDpushButton->setText(QApplication::translate("MainWindow", "back(B)", nullptr));
#ifndef QT_NO_SHORTCUT
        backDpushButton->setShortcut(QApplication::translate("MainWindow", "B", nullptr));
#endif // QT_NO_SHORTCUT
        ExitButton->setText(QApplication::translate("MainWindow", "exit(Esc)", nullptr));
#ifndef QT_NO_SHORTCUT
        ExitButton->setShortcut(QApplication::translate("MainWindow", "Esc", nullptr));
#endif // QT_NO_SHORTCUT
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
