#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "basicf.h"
#include "e_acdialog.h"
#include "u_acdialog.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
	ui->equipmentlabel->setVisible(false);
    ui->userlabel->setVisible(false);
	ui->recordlabel->setVisible(false);
    ui->backDpushButton->setVisible(false);
	ui->searchButton->setVisible(false);
	ui->UFButton->setVisible(false);
	ui->EFButton->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui; 
}

//show the information of user
void MainWindow::on_userDpushButton_clicked()
{  
     QString display=getAll(Ufile);
	 ui->textBrowser->clear();
     ui->textBrowser->insertPlainText(display);
	 ui->userlabel->setVisible(true);
     ui->equipmentDpushButton->setVisible(false);
     ui->recordButton->setVisible(false);
	 ui->searchButton->setVisible(false);
     ui->userDpushButton->setVisible(false);
     ui->backDpushButton->setVisible(true);
     ui->UFButton->setVisible(true);
}

//show the information of eqpuipment
void MainWindow::on_equipmentDpushButton_clicked()
{
    QString display=getAll(Efile);
    ui->textBrowser->clear();
    ui->textBrowser->insertPlainText(display);
    ui->equipmentlabel->setVisible(true);
    ui->equipmentDpushButton->setVisible(false);
    ui->recordButton->setVisible(false);
	ui->searchButton->setVisible(false);
    ui->userDpushButton->setVisible(false);
    ui->backDpushButton->setVisible(true);
    ui->EFButton->setVisible(true);
}

//show the back button
void MainWindow::on_backDpushButton_clicked()
{
    ui->textBrowser->clear();
    ui->equipmentlabel->setVisible(false);
    ui->userlabel->setVisible(false);
	ui->recordlabel->setVisible(false);
    ui->equipmentDpushButton->setVisible(true);
    ui->userDpushButton->setVisible(true);
    ui->recordButton->setVisible(true);
    ui->backDpushButton->setVisible(false);
    ui->UFButton->setVisible(false);
    ui->EFButton->setVisible(false);
	ui->searchButton->setVisible(false);
	ui->recordButton->setText("record(R)");
}


//equipment function window
void MainWindow::on_EFButton_clicked()
{
    E_ACDialog E_AC;
	if(E_AC.exec() == QDialog::Accepted){
	QString display = getAll(Efile);
	ui->textBrowser->clear();
	ui->textBrowser->insertPlainText(display);
	}
}

//user function window
void MainWindow::on_UFButton_clicked()
{
    U_ACDialog U_AC;
    if(U_AC.exec() == QDialog::Accepted){
    QString display = getAll(Ufile);
    ui->textBrowser->clear();
    ui->textBrowser->insertPlainText(display);
    }
}

void MainWindow::on_recordButton_clicked()
{
	ui->recordButton->setText("record(R)");
    QString display=getAll(Rfile);
    ui->textBrowser->clear();
    ui->textBrowser->insertPlainText(display);
	ui->recordlabel->setVisible(true);
	ui->searchButton->setVisible(true);
    ui->equipmentlabel->setVisible(false);
    ui->recordButton->setVisible(false);
    ui->equipmentDpushButton->setVisible(false);
    ui->userDpushButton->setVisible(false);
    ui->backDpushButton->setVisible(true);

}

void MainWindow::on_searchButton_clicked()
{
    bool ok;
	QString display;
    QString text = QInputDialog::getText(this, tr("Search"),
        tr("Input user or equipment ID: "), QLineEdit::Normal,nullptr,&ok);
    if(ok){
        if(text.length()==4){
			display=searchrecord(text, 3);
			ui->textBrowser->clear();
			ui->textBrowser->insertPlainText(display);
			
			ui->recordButton->setVisible(true);
			ui->searchButton->setVisible(false);
        }
        else if (text.length()==6) {
			display=searchrecord(text, 1);
			ui->textBrowser->clear();
			ui->textBrowser->insertPlainText(display);
			
			ui->recordButton->setVisible(true);
			ui->searchButton->setVisible(false);
        }
		else {
			QMessageBox::warning(this, tr("warning!"), tr("no such record"), QMessageBox::Ok);
		}
    }

}
