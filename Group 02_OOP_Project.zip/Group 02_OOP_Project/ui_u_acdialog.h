/********************************************************************************
** Form generated from reading UI file 'u_acdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_U_ACDIALOG_H
#define UI_U_ACDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_U_ACDialog
{
public:
    QVBoxLayout *verticalLayout;
    QPushButton *addButton;
    QPushButton *changeButton;
    QPushButton *deleteButton;
    QHBoxLayout *horizontalLayout;
    QLabel *IDlabel;
    QLineEdit *IDlineEdit;
    QComboBox *IDcomboBox;
    QLabel *Namelabel;
    QLineEdit *NamelineEdit;
    QLabel *DOBlabel;
    QLineEdit *DOBlineEdit;
    QLabel *Addresslabel;
    QLineEdit *AddresslineEdit;
    QLabel *Ranklabel;
    QComboBox *SCTcomboBox;
    QComboBox *SCMcomboBox;
    QPushButton *changeOKButton;
    QPushButton *addOKButton;
    QPushButton *deleteOKButton;
    QPushButton *changesaveButton;
    QPushButton *addsaveButton;
    QPushButton *BackButton;

    void setupUi(QDialog *U_ACDialog)
    {
        if (U_ACDialog->objectName().isEmpty())
            U_ACDialog->setObjectName(QString::fromUtf8("U_ACDialog"));
        U_ACDialog->resize(483, 706);
        verticalLayout = new QVBoxLayout(U_ACDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        addButton = new QPushButton(U_ACDialog);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        verticalLayout->addWidget(addButton);

        changeButton = new QPushButton(U_ACDialog);
        changeButton->setObjectName(QString::fromUtf8("changeButton"));

        verticalLayout->addWidget(changeButton);

        deleteButton = new QPushButton(U_ACDialog);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        verticalLayout->addWidget(deleteButton);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        IDlabel = new QLabel(U_ACDialog);
        IDlabel->setObjectName(QString::fromUtf8("IDlabel"));
        QFont font;
        font.setPointSize(20);
        IDlabel->setFont(font);

        horizontalLayout->addWidget(IDlabel);

        IDlineEdit = new QLineEdit(U_ACDialog);
        IDlineEdit->setObjectName(QString::fromUtf8("IDlineEdit"));

        horizontalLayout->addWidget(IDlineEdit);

        IDcomboBox = new QComboBox(U_ACDialog);
        IDcomboBox->addItem(QString());
        IDcomboBox->addItem(QString());
        IDcomboBox->addItem(QString());
        IDcomboBox->addItem(QString());
        IDcomboBox->setObjectName(QString::fromUtf8("IDcomboBox"));

        horizontalLayout->addWidget(IDcomboBox);


        verticalLayout->addLayout(horizontalLayout);

        Namelabel = new QLabel(U_ACDialog);
        Namelabel->setObjectName(QString::fromUtf8("Namelabel"));
        Namelabel->setFont(font);

        verticalLayout->addWidget(Namelabel);

        NamelineEdit = new QLineEdit(U_ACDialog);
        NamelineEdit->setObjectName(QString::fromUtf8("NamelineEdit"));

        verticalLayout->addWidget(NamelineEdit);

        DOBlabel = new QLabel(U_ACDialog);
        DOBlabel->setObjectName(QString::fromUtf8("DOBlabel"));
        DOBlabel->setFont(font);

        verticalLayout->addWidget(DOBlabel);

        DOBlineEdit = new QLineEdit(U_ACDialog);
        DOBlineEdit->setObjectName(QString::fromUtf8("DOBlineEdit"));

        verticalLayout->addWidget(DOBlineEdit);

        Addresslabel = new QLabel(U_ACDialog);
        Addresslabel->setObjectName(QString::fromUtf8("Addresslabel"));
        Addresslabel->setFont(font);

        verticalLayout->addWidget(Addresslabel);

        AddresslineEdit = new QLineEdit(U_ACDialog);
        AddresslineEdit->setObjectName(QString::fromUtf8("AddresslineEdit"));

        verticalLayout->addWidget(AddresslineEdit);

        Ranklabel = new QLabel(U_ACDialog);
        Ranklabel->setObjectName(QString::fromUtf8("Ranklabel"));
        Ranklabel->setFont(font);

        verticalLayout->addWidget(Ranklabel);

        SCTcomboBox = new QComboBox(U_ACDialog);
        SCTcomboBox->addItem(QString());
        SCTcomboBox->addItem(QString());
        SCTcomboBox->addItem(QString());
        SCTcomboBox->setObjectName(QString::fromUtf8("SCTcomboBox"));

        verticalLayout->addWidget(SCTcomboBox);

        SCMcomboBox = new QComboBox(U_ACDialog);
        SCMcomboBox->addItem(QString());
        SCMcomboBox->addItem(QString());
        SCMcomboBox->addItem(QString());
        SCMcomboBox->setObjectName(QString::fromUtf8("SCMcomboBox"));

        verticalLayout->addWidget(SCMcomboBox);

        changeOKButton = new QPushButton(U_ACDialog);
        changeOKButton->setObjectName(QString::fromUtf8("changeOKButton"));

        verticalLayout->addWidget(changeOKButton);

        addOKButton = new QPushButton(U_ACDialog);
        addOKButton->setObjectName(QString::fromUtf8("addOKButton"));

        verticalLayout->addWidget(addOKButton);

        deleteOKButton = new QPushButton(U_ACDialog);
        deleteOKButton->setObjectName(QString::fromUtf8("deleteOKButton"));

        verticalLayout->addWidget(deleteOKButton);

        changesaveButton = new QPushButton(U_ACDialog);
        changesaveButton->setObjectName(QString::fromUtf8("changesaveButton"));

        verticalLayout->addWidget(changesaveButton);

        addsaveButton = new QPushButton(U_ACDialog);
        addsaveButton->setObjectName(QString::fromUtf8("addsaveButton"));

        verticalLayout->addWidget(addsaveButton);

        BackButton = new QPushButton(U_ACDialog);
        BackButton->setObjectName(QString::fromUtf8("BackButton"));

        verticalLayout->addWidget(BackButton);


        retranslateUi(U_ACDialog);
        QObject::connect(BackButton, SIGNAL(clicked()), U_ACDialog, SLOT(close()));
        QObject::connect(deleteOKButton, SIGNAL(clicked()), U_ACDialog, SLOT(accept()));
        QObject::connect(changesaveButton, SIGNAL(clicked()), U_ACDialog, SLOT(accept()));
        QObject::connect(addsaveButton, SIGNAL(clicked()), U_ACDialog, SLOT(accept()));

        QMetaObject::connectSlotsByName(U_ACDialog);
    } // setupUi

    void retranslateUi(QDialog *U_ACDialog)
    {
        U_ACDialog->setWindowTitle(QApplication::translate("U_ACDialog", "Dialog", nullptr));
        addButton->setText(QApplication::translate("U_ACDialog", "add(A)", nullptr));
#ifndef QT_NO_SHORTCUT
        addButton->setShortcut(QApplication::translate("U_ACDialog", "A", nullptr));
#endif // QT_NO_SHORTCUT
        changeButton->setText(QApplication::translate("U_ACDialog", "change(C)", nullptr));
#ifndef QT_NO_SHORTCUT
        changeButton->setShortcut(QApplication::translate("U_ACDialog", "C", nullptr));
#endif // QT_NO_SHORTCUT
        deleteButton->setText(QApplication::translate("U_ACDialog", "delete(D)", nullptr));
#ifndef QT_NO_SHORTCUT
        deleteButton->setShortcut(QApplication::translate("U_ACDialog", "D", nullptr));
#endif // QT_NO_SHORTCUT
        IDlabel->setText(QApplication::translate("U_ACDialog", "ID:", nullptr));
        IDcomboBox->setItemText(0, QApplication::translate("U_ACDialog", "VEN", nullptr));
        IDcomboBox->setItemText(1, QApplication::translate("U_ACDialog", "ROV", nullptr));
        IDcomboBox->setItemText(2, QApplication::translate("U_ACDialog", "SCT", nullptr));
        IDcomboBox->setItemText(3, QApplication::translate("U_ACDialog", "SCM", nullptr));

        Namelabel->setText(QApplication::translate("U_ACDialog", "Name:", nullptr));
        DOBlabel->setText(QApplication::translate("U_ACDialog", "Date of Birth:", nullptr));
        Addresslabel->setText(QApplication::translate("U_ACDialog", "Address:", nullptr));
        Ranklabel->setText(QApplication::translate("U_ACDialog", "Rank:", nullptr));
        SCTcomboBox->setItemText(0, QApplication::translate("U_ACDialog", "Member", nullptr));
        SCTcomboBox->setItemText(1, QApplication::translate("U_ACDialog", "Patrol Leader", nullptr));
        SCTcomboBox->setItemText(2, QApplication::translate("U_ACDialog", "Assistant Patrol Leader", nullptr));

        SCMcomboBox->setItemText(0, QApplication::translate("U_ACDialog", "Scout Leader", nullptr));
        SCMcomboBox->setItemText(1, QApplication::translate("U_ACDialog", "Assistant Scout Leader", nullptr));
        SCMcomboBox->setItemText(2, QApplication::translate("U_ACDialog", "Rover Scout Leader", nullptr));

        changeOKButton->setText(QApplication::translate("U_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        changeOKButton->setShortcut(QApplication::translate("U_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        addOKButton->setText(QApplication::translate("U_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        addOKButton->setShortcut(QApplication::translate("U_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        deleteOKButton->setText(QApplication::translate("U_ACDialog", "OK", nullptr));
#ifndef QT_NO_SHORTCUT
        deleteOKButton->setShortcut(QApplication::translate("U_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        changesaveButton->setText(QApplication::translate("U_ACDialog", "save", nullptr));
#ifndef QT_NO_SHORTCUT
        changesaveButton->setShortcut(QApplication::translate("U_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        addsaveButton->setText(QApplication::translate("U_ACDialog", "save", nullptr));
#ifndef QT_NO_SHORTCUT
        addsaveButton->setShortcut(QApplication::translate("U_ACDialog", "Return", nullptr));
#endif // QT_NO_SHORTCUT
        BackButton->setText(QApplication::translate("U_ACDialog", "Back(B)", nullptr));
#ifndef QT_NO_SHORTCUT
        BackButton->setShortcut(QApplication::translate("U_ACDialog", "B", nullptr));
#endif // QT_NO_SHORTCUT
    } // retranslateUi

};

namespace Ui {
    class U_ACDialog: public Ui_U_ACDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_U_ACDIALOG_H
