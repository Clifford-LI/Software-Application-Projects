#ifndef USERWINDOW_H
#define USERWINDOW_H

#include <QMainWindow>
#include "userc.h"
#include <QMessageBox>
#include <QInputDialog>
namespace Ui {
class UserWindow;
}

class UserWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserWindow(QWidget *parent = nullptr);
    ~UserWindow();
	void setid(QString Id);

private slots:
    void on_borrowButton_clicked();

    void on_returnButton_clicked();

private:
	QString id;
    Ui::UserWindow *ui;
};

#endif // USERWINDOW_H
