#ifndef E_ACDIALOG_H
#define E_ACDIALOG_H

#include <QDialog>
#include "tent.h" 
#include "stove.h"
#include "lantern.h"
namespace Ui {
class E_ACDialog;
}

class E_ACDialog : public QDialog
{
    Q_OBJECT

public:
    explicit E_ACDialog(QWidget *parent = nullptr);
    ~E_ACDialog();

private slots:
    void on_addButton_clicked();

    void on_addOKButton_clicked();

    void on_changeButton_clicked();

    void on_changeOKButton_clicked();

    void on_changesaveButton_clicked();

    void on_addsaveButton_clicked();

    void on_deleteButton_clicked();

    void on_deleteOKButton_clicked();

private:
    Ui::E_ACDialog *ui;
};

#endif // E_ACDIALOG_H
