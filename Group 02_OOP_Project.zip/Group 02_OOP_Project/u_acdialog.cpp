#include "u_acdialog.h"
#include "ui_u_acdialog.h"
#include "QMessageBox"

U_ACDialog::U_ACDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::U_ACDialog)
{
    ui->setupUi(this);

    ui->IDlabel->setVisible(false);
    ui->IDlineEdit->setVisible(false);
    ui->IDcomboBox->setVisible(false);

    ui->Namelabel->setVisible(false);
    ui->NamelineEdit->setVisible(false);

    ui->DOBlabel->setVisible(false);
    ui->DOBlineEdit->setVisible(false);

    ui->Addresslabel->setVisible(false);
    ui->AddresslineEdit->setVisible(false);

    ui->Ranklabel->setVisible(false);
    ui->SCMcomboBox->setVisible(false);
    ui->SCTcomboBox->setVisible(false);

    ui->addOKButton->setVisible(false);
    ui->changeOKButton->setVisible(false);
    ui->deleteOKButton->setVisible(false);

    ui->addsaveButton->setVisible(false);
    ui->changesaveButton->setVisible(false);
}

U_ACDialog::~U_ACDialog()
{
    delete ui;
}

//add
void U_ACDialog::on_addButton_clicked()
{
    ui->addButton->setVisible(false);
    ui->changeButton->setVisible(false);
    ui->deleteButton->setVisible(false);

    ui->addOKButton->setVisible(true);

    ui->IDlabel->setVisible(true);
    ui->IDcomboBox->setVisible(true);
}

void U_ACDialog::on_addOKButton_clicked()
{
	QString ID = ui->IDcomboBox->currentText();

	ui->IDlabel->setVisible(false);
	ui->IDlineEdit->setVisible(false);
	ui->IDcomboBox->setVisible(false);

	ui->addsaveButton->setVisible(true);
	ui->addOKButton->setVisible(false);

	if (ID.startsWith("S")) {
		ui->Namelabel->setVisible(true);
		ui->NamelineEdit->setVisible(true);

		ui->DOBlabel->setVisible(true);
		ui->DOBlineEdit->setVisible(true);

		ui->Addresslabel->setVisible(true);
		ui->AddresslineEdit->setVisible(true);

		ui->Ranklabel->setVisible(true);
		if(ID.startsWith("SCM"))
			ui->SCMcomboBox->setVisible(true);
		else
			ui->SCTcomboBox->setVisible(true);
	}
	else {
		ui->Namelabel->setVisible(true);
		ui->NamelineEdit->setVisible(true);

		ui->DOBlabel->setVisible(true);
		ui->DOBlineEdit->setVisible(true);

		ui->Addresslabel->setVisible(true);
		ui->AddresslineEdit->setVisible(true);
	}
}

void U_ACDialog::on_addsaveButton_clicked()
{
	QString ID = ui->IDcomboBox->currentText();

	User add(ID);

	add.setName(ui->NamelineEdit->text());
	add.setDateOfBirth(ui->DOBlineEdit->text());
	add.setAddress(ui->AddresslineEdit->text());
	if (ID.startsWith("SCM"))
		add.setRank(ui->SCMcomboBox->currentText());
	if (ID.startsWith("SCT"))
		add.setRank(ui->SCTcomboBox->currentText());

	add.saveadd();
}


//change
void U_ACDialog::on_changeButton_clicked()
{
	ui->addButton->setVisible(false);
	ui->changeButton->setVisible(false);
	ui->deleteButton->setVisible(false);

	ui->changeOKButton->setVisible(true);

	ui->IDlabel->setVisible(true);
	ui->IDlineEdit->setVisible(true);
}

void U_ACDialog::on_changeOKButton_clicked()
{
	QString ID = ui->IDlineEdit->text();
	QString Uline = searchData(Ufile, ID);

	if (QString::compare(Uline, "wrong") == 0 || ID.length() != 6) {
		ui->IDlineEdit->clear();
		QMessageBox::warning(this, tr("warning!"), tr("Wrong!"), QMessageBox::Ok);
	}
	else {
		User T(ID);

		ui->IDlabel->setVisible(false);
		ui->IDlineEdit->setVisible(false);
		ui->IDcomboBox->setVisible(false);

		ui->changesaveButton->setVisible(true);
		ui->changeOKButton->setVisible(false);

		if (ID.startsWith("S")) {
			ui->Namelabel->setVisible(true);
			ui->NamelineEdit->setVisible(true);
			ui->NamelineEdit->setText(T.getName());

			ui->DOBlabel->setVisible(true);
			ui->DOBlineEdit->setVisible(true);
			ui->DOBlineEdit->setText(T.getDateOfBirth());

			ui->Addresslabel->setVisible(true);
			ui->AddresslineEdit->setVisible(true);
			ui->AddresslineEdit->setText(T.getAddress());

			ui->Ranklabel->setVisible(true);
			QString TR = T.getRank();
			if (ID.startsWith("SCM")) {
				ui->SCMcomboBox->setVisible(true);
				if (TR.startsWith("Scout Leader")) {
					ui->SCMcomboBox->setCurrentIndex(0);
				}
				else if (TR.startsWith("Assistant Scout Leader")) {
					ui->SCMcomboBox->setCurrentIndex(1);
				}
				else {
					ui->SCMcomboBox->setCurrentIndex(2);
				}
			}
			else {
				ui->SCTcomboBox->setVisible(true);
				
				if (TR.startsWith("Member")) {
					ui->SCTcomboBox->setCurrentIndex(0);
				}
				else if (TR.startsWith("Patrol Leader")) {
					ui->SCTcomboBox->setCurrentIndex(1);
				}
				else {
					ui->SCTcomboBox->setCurrentIndex(2);
				}
			}
		}
		else {
			ui->Namelabel->setVisible(true);
			ui->NamelineEdit->setVisible(true);
			ui->NamelineEdit->setText(T.getName());

			ui->DOBlabel->setVisible(true);
			ui->DOBlineEdit->setVisible(true);
			ui->DOBlineEdit->setText(T.getDateOfBirth());

			ui->Addresslabel->setVisible(true);
			ui->AddresslineEdit->setVisible(true);
			ui->AddresslineEdit->setText(T.getAddress());
		}
		ui->changeOKButton->setVisible(false);
	}
}

void U_ACDialog::on_changesaveButton_clicked()
{
	QString ID = ui->IDlineEdit->text();
	User change(ID);

	change.setName(ui->NamelineEdit->text());
	change.setDateOfBirth(ui->DOBlineEdit->text());
	change.setAddress(ui->AddresslineEdit->text());
	if (ID.startsWith("SCM"))
		change.setRank(ui->SCMcomboBox->currentText());
	if(ID.startsWith("SCT"))
		change.setRank(ui->SCTcomboBox->currentText());

	change.savechange();
}


//delete
void U_ACDialog::on_deleteButton_clicked()
{
    ui->addButton->setVisible(false);
    ui->changeButton->setVisible(false);
    ui->deleteButton->setVisible(false);

    ui->deleteOKButton->setVisible(true);

    ui->IDlabel->setVisible(true);
    ui->IDlineEdit->setVisible(true);
}

void U_ACDialog::on_deleteOKButton_clicked()
{
	QString ID=ui->IDlineEdit->text();
	User del(ID);
	int num = searchlineN(Ufile, ID);
	if (ID.length() != 6 || num == 0) {
		ui->IDlineEdit->clear();
		QMessageBox::warning(this, tr("warning!"), tr("ID is incorrect!"), QMessageBox::Ok);
	}
	else if (del.NumberOfBorrow()) {
		ui->IDlineEdit->clear();
		QMessageBox::warning(this, tr("warning!"), tr("%1 has not returned all items yet!").arg(ID), QMessageBox::Ok);
	}
	else {
		del.savedel();
	}
}




